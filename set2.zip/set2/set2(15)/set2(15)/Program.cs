﻿//Se da o secventa de n numere. Sa se determine daca este bitonica. 
using System;

class Program
{
    static int checkBitonic(int[] arr,
                            int n)
    {
        int i, j;
        for (i = 1; i < n; i++)
        {
            if (arr[i] > arr[i - 1])
                continue;

            if (arr[i] <= arr[i - 1])
                break;
        }

        if (i == n - 1)
            return 1;
        for (j = i + 1; j < n; j++)
        {
            if (arr[j] < arr[j - 1])
                continue;

            if (arr[j] >= arr[j - 1])
                break;
        }

        i = j;

        if (i != n)
            return 0;

        return 1;
    }
    public static void Main()
    {
        int[] arr = { -3, 9, 7, 20, 17, 5, 1 };

        int n = arr.Length;

        Console.WriteLine((
                checkBitonic(arr, n) == 1) ?
                                    "DA" : "NU");
    }
}
﻿//Se da o secventa de n numere. Sa se determine cate din ele sunt pare. 
using System;

class Program
{
    static int countEvenOdd(int n)
    {
        int even_count = 0;
        int odd_count = 0;
        while (n > 0)
        {
            int rem = n % 10;
            if (rem % 2 == 0)
                even_count++;
            else
                odd_count++;
            n = n / 10;
        }

        Console.WriteLine("Numere pare : " +
                        even_count);
        Console.WriteLine("Numere impare : " +
                        odd_count);
        if (even_count % 2 == 0 &&
            odd_count % 2 != 0)
            return 1;
        else
            return 0;
    }

    public static void Main()
    {
        int n;
        n = 445325;
        int t = countEvenOdd(n);

    }
}

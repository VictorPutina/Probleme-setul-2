﻿using System;
using System.Linq;
using System.Collections.Generic;

public class Example
{
    public static void Main()
    {
        List<int> list = new List<int>() { 5, -1, 4, 9, -7, 8 };

        Console.WriteLine("Elementul maxim " + list.Max());
        Console.WriteLine("Elementul minim " + list.Min());
    }
}

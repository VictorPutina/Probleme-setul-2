﻿//Determinati daca o secventa de n numere este o secventa monotona rotita. 
using System;
class Program
{
    static bool check(int[] arr)
    {
        int N = arr.Length;
        bool inc = true;
        bool dec = true;
        for (int i = 0; i < N - 1; i++)
        {
            if (arr[i] > arr[i + 1])
            {
                inc = false;
            }
        }
        for (int i = 0; i < N - 1; i++)
        {
            if (arr[i] < arr[i + 1])
            {
                dec = false;
            }
        }
        return (inc || dec);
    }
    public static void Main()
    {
        int[] arr = { 1, 2, 3, 3 };
        bool ans = check(arr);
        if (ans)
            Console.Write("DA");
        else
            Console.Write("NU");
    }
}
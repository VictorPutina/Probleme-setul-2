﻿//Se da o secventa de n numere. Care este numarul maxim de numere consecutive egale din secventa. 
using System;
using System.Collections.Generic;
public

class GFG
{

    static int findLongestConseqSubseq(int[] arr, int n)
    {
        HashSet<int> S = new HashSet<int>();
        for (int i = 0; i < n; i++)
            S.Add(arr[i]);
        int ans = 0;
        for (int i = 0; i < n; i++)
        {
            if (S.Contains(arr[i]))
            {
                int j = arr[i];
                while (S.Contains(j))
                    j++;
                ans = Math.Max(ans, j - arr[i]);
            }
        }
        return ans;
    }
    public static void Main(String[] args)
    {
        int[] arr = { 1, 94, 93, 1000, 5, 92, 78 };
        int n = arr.Length;
        Console.WriteLine(findLongestConseqSubseq(arr, n));
    }
}
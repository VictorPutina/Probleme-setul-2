﻿//Se da o secventa de n numere. Se cere sa se caculeze suma inverselor acestor numere. 
using System;

class Program
{
    static int findSum(int N, int K)
    {
        int ans = 0;
        for (int i = 1; i <= N; i++)
            ans += (i % K);

        return ans;
    }

    static public void Main()
    {
        int N = 10, K = 2;
        Console.WriteLine(findSum(N, K));
    }
}